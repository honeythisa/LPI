#Faça um programa que permita a leitura dos nomes de 5 pessoas e armazene os nomes
#lidos em uma lista. Após isto, o algoritmo deve permitir a leitura de mais 1 nome
#qualquer e depois escrever a mensagem ACHEI, se o nome estiver entre os 10 nomes
#lidos anteriormente (guardados na lista), ou NÃO ACHEI caso contrário.

i = 0
while i <5:
    nomes = input("Digite um nome: ")
    i = i + 1

leitura = input("Digite mais um nome: ")

lista = [nomes]

if leitura in lista:
    print("ACHEI")
else:
    print("NÃO ACHEI")