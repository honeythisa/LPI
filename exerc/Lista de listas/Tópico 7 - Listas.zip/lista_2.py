# Crie uma lista chamada “tabuada”com os valores de 1 até 10. A seguir,peça um número ao
# usuário e multiplique cada número da lista pelo número informado
# e o armazene no lugar do número antigo.
# Ao final mostre a lista modificada com o resultado da tabuada.

tabuada = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

pedido = int(input("Digite um número: "))

i = 0
while i < len(tabuada):  # len(<nome da lista>) é usado para ver quantos itens há na lista.
    tabuada[i] = tabuada[i]*pedido
    i = i + 1

print(pedido,"multiplicado por cada número de 1 à 10 é",tabuada)