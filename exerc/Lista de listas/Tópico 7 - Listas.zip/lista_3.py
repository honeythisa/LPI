# Crie uma lista e peça 5 números ao usuário para preencher a lista.
# Ao final, percorra a lista e encontre o maior número.

lista = []
max = min = i = 0

while i <5:
    num = int(input('Digite um número qualquer :'))
    lista.append(num) ## append serve para adicionar um item no final.
    i = i + 1

    if num > max:
        max = num

print("O maior valor digitado foi", max)