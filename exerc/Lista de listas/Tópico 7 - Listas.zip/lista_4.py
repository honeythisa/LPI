# Crie 2 listas, uma chamada “pares” e outra chamada “impares”.
# Peça que o usuário informe 10 números e a cada número
# lido o coloque em sua respectiva lista.
# Ao final imprima as duas listas, uma em cada linha.

pares = []
impares = []

i = 0
while i <10:
    pedido = int(input("Digite um número: "))
    i = i + 1

    if pedido % 2 == 0:
        pares.append(pedido)
    else:
        impares.append(pedido)
print("Esses são os números pares que você digitou:", pares)
print("Esses são os números ímpares que você digitou:", impares)