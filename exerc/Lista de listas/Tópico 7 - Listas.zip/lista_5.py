# + : adiciona um novo elemento no final da lista (deve informar o nome a ser adicionado).
# - : remove o último elemento da lista
# ++ : adiciona um novo elemento em uma posição específica da lista (lembre-se de
# perguntar qual posição o usuário deseja inserir, caso essa opção seja selecionada).
# -- : remove um elemento em uma posição específica da lista (lembre-se de perguntar
# qual posição o usuário deseja remover, caso essa opção seja selecionada).
# BUSCAR : procura o elemento na lista e informa se encontrou ou não (deve informar o
# nome a ser procurado).
# VER: informa uma posição e exibe na tela o nome armazenado nesta posição.
# LISTAR: exibe toda a lista na tela.
# TAMANHO: exibe o tamanho da lista na tela.

lista_de_nomes = []

print("✎ Comandos para criar uma lista: ――――――――――――――――――――――――――――――――﹁ \n"
      "| +  : adiciona um novo elemento no final da lista;                                    | \n"
      "| -  : remove o último elemento da lista;                                              | \n"
      "| ++ : adiciona um novo elemento em uma posição específica da lista;                   | \n"
      "| -- : remove um elemento em uma posição específica da lista;                          | \n"
      "| BUSCAR: procura o elemento na lista e informa se encontrou ou não                    | \n"
      "| VER: informa uma posição e exibe na tela o nome armazenado nesta posição;            | \n"
      "| LISTAR: exibe toda a lista na tela;                                                  | \n"
      "| TAMANHO: exibe o tamanho da lista na tela;                                           | \n"
      "﹂―――――――――――――――――――――――――――――――――――――――――――――――――――――")
while True:
    comando = input("Para montar/arrumar sua lista escolha um dos comandos e digite aqui ➪ ")

    if comando == "+":
        nome_informado = input("Informe o elemento: ")
        lista_de_nomes.append(nome_informado)

    if comando == "-":
        lista_de_nomes.pop()

    if comando == "++":
        pedido = input(" Informe qual elemento você deseja adicionar: ")
        pos = int(input("OBS: 0 (ZERO) é a primeira posição (índice) \n"
                            "Em qual posição você deseja inserir?: "))
        lista_de_nomes.insert(pos, pedido)

    if comando == "--":
        pos1 = int(input("OBS: 0 (ZERO) é a primeira posição (índice) \n" 
                             "Em qual posição você deseja remover?: "))
        lista_de_nomes.pop(pos1)

    print(lista_de_nomes)

        # --> Verificar se um valor existe
        # (deve informar o nome a ser procurado)
    if comando == "BUSCAR":
        pedido1 = input("Qual elemento você deseja buscar?: ")
        if pedido1 in lista_de_nomes:
            print(pedido1, "está na lista!")
        else:
            print(pedido1, "não está na lista!")

    if comando == "VER":
        pedido3 = int(input("OBS: 0 (ZERO) é a primeira posição (índice) \n"
                            "Qual a posição você deseja ver?: "))
        print(lista_de_nomes[pedido3])

    if comando == "LISTAR":
        print(lista_de_nomes)

    if comando == "TAMANHO":
        tamanho = len(lista_de_nomes)
        print("O tamanho da sua lista é",tamanho)